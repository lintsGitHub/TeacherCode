create procedure pp1()
  begin
    declare v1 int default 100;

    set @aaa = v1*101;
  end;

