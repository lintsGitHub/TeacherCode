create view v_gd_mvp as
  select `c`.`city`         AS `city2`,
         `p`.`pid`          AS `pid`,
         `p`.`city`         AS `city`,
         `p`.`company`      AS `company`,
         `p`.`position`     AS `position`,
         `p`.`field`        AS `field`,
         `p`.`salary_min`   AS `salary_min`,
         `p`.`salary_max`   AS `salary_max`,
         `p`.`workyear`     AS `workyear`,
         `p`.`education`    AS `education`,
         `p`.`ptype`        AS `ptype`,
         `p`.`pnature`      AS `pnature`,
         `p`.`advantage`    AS `advantage`,
         `p`.`published_at` AS `published_at`,
         `p`.`updated_at`   AS `updated_at`
  from (`lagou`.`lagou_pos` `p`
      join `lagou`.`lagou_city` `c` on (`p`.`city` = `c`.`cid`))
  where `c`.`province` = '广东省'
  order by `p`.`salary_min` desc
  limit 10;

