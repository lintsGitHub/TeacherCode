create procedure pro_insert_into(IN sum int)
  begin
    declare i int default 0;
    declare name varchar(20);
    declare weixin varchar(20);

    while i < sum do
      set i = i + 1;

      # substring 函数，第一个参数是要分割的字符串
      set name = substring(md5(rand()),9,7); #索引9开始截取7个长度
      set weixin = substring(rand(),3,6);  #索引3开始，截取6个长度

      insert into t_person(name,weixin) values (name,weixin);
    end while;
  end;

