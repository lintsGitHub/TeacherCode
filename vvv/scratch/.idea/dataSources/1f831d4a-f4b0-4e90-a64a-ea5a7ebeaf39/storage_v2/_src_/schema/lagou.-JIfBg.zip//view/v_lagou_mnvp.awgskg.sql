create view v_lagou_mnvp as
  select `lagou`.`lagou_pos`.`pid`          AS `pid`,
         `lagou`.`lagou_pos`.`city`         AS `city`,
         `lagou`.`lagou_pos`.`company`      AS `company`,
         `lagou`.`lagou_pos`.`position`     AS `position`,
         `lagou`.`lagou_pos`.`field`        AS `field`,
         `lagou`.`lagou_pos`.`salary_min`   AS `salary_min`,
         `lagou`.`lagou_pos`.`salary_max`   AS `salary_max`,
         `lagou`.`lagou_pos`.`workyear`     AS `workyear`,
         `lagou`.`lagou_pos`.`education`    AS `education`,
         `lagou`.`lagou_pos`.`ptype`        AS `ptype`,
         `lagou`.`lagou_pos`.`pnature`      AS `pnature`,
         `lagou`.`lagou_pos`.`advantage`    AS `advantage`,
         `lagou`.`lagou_pos`.`published_at` AS `published_at`,
         `lagou`.`lagou_pos`.`updated_at`   AS `updated_at`
  from `lagou`.`lagou_pos`
  order by `lagou`.`lagou_pos`.`salary_min`
  limit 10;

