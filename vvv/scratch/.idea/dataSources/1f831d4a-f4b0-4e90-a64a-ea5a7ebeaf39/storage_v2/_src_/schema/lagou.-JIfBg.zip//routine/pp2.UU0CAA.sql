create procedure pp2()
  begin
    declare v1 int default 100;

    select count(*) into @bbb from t_person;
    select weixin into @ccc from t_person limit 1;
  end;

