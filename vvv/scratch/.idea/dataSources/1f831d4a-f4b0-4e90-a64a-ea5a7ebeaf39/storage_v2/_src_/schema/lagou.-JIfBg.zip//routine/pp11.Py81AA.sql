create procedure pp11()
  begin
    declare rrr int default 333;

    select * from lagou_city limit 10;
    select * from t_person limit 50;
    select rrr * 23;
  end;

