create procedure ran(IN sum int)
  begin
    declare i int default 0;
    declare name varchar(20);
    declare weixin varchar(20);

    while i < sum do
      set i = i + 1;

      set name = right(rand()*1000000,6);
      set weixin = right(rand()*1000000,6);

      insert into t_person(name,weixin) values (name,weixin);
    end while;
  end;

