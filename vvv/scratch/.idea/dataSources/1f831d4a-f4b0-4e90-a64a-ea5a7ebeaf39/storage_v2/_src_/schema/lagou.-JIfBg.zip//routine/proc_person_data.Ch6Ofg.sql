create procedure proc_person_data(IN num int)
  begin
    declare ii int default 0;

    -- while .. end while
    -- repeat .. until .. end repeat
    -- loop_label:loop ... leave loop_label .. end loop;

    set autocommit = 0;
    while ii < num do
      insert into t_person (name, weixin) values (concat('user_', rand_str(6, 1)), rand_str(8, 2));
      set ii = ii + 1;

      if ii % 100000 = 1 then commit ; end if;
    end while;

    commit ;
  end;

