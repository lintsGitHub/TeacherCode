create procedure pro_person_data(IN num int)
  begin
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    declare ii int default 0;

    
    
    
    while ii < num do
          insert into t_person (name, weixin) values ('222', '333');
          set ii = ii + 1;
    end while;
end;

