create procedure pp4(OUT sum bigint)
  begin
    declare iii int;
    declare done int default 0;

    declare c_person cursor for select weixin from t_person; -- 1. 游标的定义
    declare continue handler for not found set done = 1;

    set sum = 0;

    open c_person; -- 2. 打开游标

    xxx:loop
      fetch c_person into iii; -- 3. 使用游标
      if done = 1 then
        leave xxx;
      end if;
      set sum = sum + iii;
    end loop;

    close c_person; -- 4. 关闭游标
  end;

